package pageObjects;

public class BasketPage {
}
